# Instructors: Making Changes to Screwedoku

+ Clone and make changes to this [repo][repo].

+ If you're zipping up this project, run the `pull_and_create.sh` script to zip it.  Don't just run the `zip` command.

+ If you want to update the README or affect all the levels, commit your changes on master and then run the `update.sh` script.  For example `./update.sh Gemfile`. Then run the `./pull_all_branches_and_zip.sh` to make a new zipfile out of the project for students.

[repo]:https://github.com/appacademy/screwedoku
